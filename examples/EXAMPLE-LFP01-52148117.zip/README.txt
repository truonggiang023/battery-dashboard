DỰ ÁN VÍ DỤ — KHÔNG PHẢI KẾT QUẢ THỬ NGHIỆM THỰC TẾ.
PRISMATIC / LFP01 / 52148117.
Mỗi mục chức năng là một file Excel, nội dung con là sheet. Không đổi tên sheet/header. Nhập giá trị, không nhập formula. File tải về là bản sao và không tự đồng bộ lên dashboard. Dữ liệu thật nằm trong dataset [THỰC] riêng biệt.
Cycler mô phỏng dùng model Digital-Twin gốc khoảng 2.5Ah, không hiệu chuẩn theo số liệu ví dụ 105Ah. Không dùng mô phỏng như kết quả Approved của dự án thật.